package com.sociaMedia.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sociaMedia.entity.Message;
import com.sociaMedia.repositoryDAO.MessageRepository;

@Service
public class MessageService {

	@Autowired
	private final MessageRepository messageRepository;

	public MessageService(MessageRepository messageRepository) {
		this.messageRepository = messageRepository;
	}

	public Message save(Message message) {
		return messageRepository.save(message);
	}

	public void deleteMessage(Long messageId) {
		messageRepository.deleteById(messageId);
	}

	public Message getMessageById(Long messageId) {
		Optional<Message> messageOptional = messageRepository.findById(messageId);
		if (messageOptional.isPresent()) {
			return messageOptional.get();
		} else {
			throw new RuntimeException("Message not found");
		}
	}

	public List<Message> getAllMessages() {
		return messageRepository.findAll();
	}

	// for testing messages between
//    public List<Message> getMessagesBetweenUsers(User user1, User user2) {
//        List<Message> messages = new ArrayList<>();
//        // loop through all messages and add the ones between the two users to the list
//        for (Message message : messages) {
//            if ((message.getSender().equals(user1) && message.getReceiver().equals(user2))
//                    || (message.getSender().equals(user2) && message.getReceiver().equals(user1))) {
//                messages.add(message);
//            }
//        }
//        return messages;
//    }

}
