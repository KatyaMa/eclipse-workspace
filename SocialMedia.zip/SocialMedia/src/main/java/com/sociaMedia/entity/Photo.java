package com.sociaMedia.entity;

public class Photo { // Photo: a class to represent photos that users can upload and share with their
						// friends

}
